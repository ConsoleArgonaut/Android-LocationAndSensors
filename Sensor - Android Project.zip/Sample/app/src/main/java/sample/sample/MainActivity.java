package sample.sample;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static float startValue = 0;
    private SensorManager mSensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initializes Sensor Manager, and adds Listener to the accelerometer
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mSensorManager.registerListener(mSensorListener, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
    }

    private final SensorEventListener mSensorListener = new SensorEventListener() {
        public void onSensorChanged(SensorEvent se) {
            //Gets x, y, z Values
            float x = se.values[0];
            float y = se.values[1];
            float z = se.values[2];
            //Sets values if not set yet
            if(startValue == 0)
                startValue = x + y + z;
            //If device is tilted, shows text "Tilted"
            if(startValue - 2 > x + y + z || startValue + 2 < x + y + z)
                ((TextView)findViewById(R.id.textView)).setText("Tilted");
            else
                ((TextView)findViewById(R.id.textView)).setText("Laying still");
        }
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };
}

